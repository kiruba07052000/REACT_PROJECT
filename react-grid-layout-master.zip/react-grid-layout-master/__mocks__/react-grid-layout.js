// Used by jest as it requires some example files, which pull from 'react-grid-layout'
module.exports = require('../index-dev');